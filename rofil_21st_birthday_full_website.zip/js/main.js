const track=document.getElementById("slides");
const slides=[...document.querySelectorAll(".slide")];
const dots=document.getElementById("dots");
let index=0,startX=0,dx=0;
slides.forEach((_,i)=>{const d=document.createElement("button");d.className="dot"+(i===0?" active":"");d.setAttribute("aria-label",`Slide ${i+1}`);d.onclick=()=>go(i);dots.appendChild(d)});
function go(i){index=Math.max(0,Math.min(slides.length-1,i));track.style.transform=`translateX(-${index*100}%)`;document.querySelectorAll(".dot").forEach((d,n)=>d.classList.toggle("active",n===index))}
function next(){go(index+1)} function prev(){go(index-1)}
document.querySelectorAll("[data-next]").forEach(b=>b.addEventListener("click",next));
track.addEventListener("touchstart",e=>{startX=e.changedTouches[0].clientX;dx=0},{passive:true});
track.addEventListener("touchmove",e=>{dx=e.changedTouches[0].clientX-startX},{passive:true});
track.addEventListener("touchend",()=>{if(Math.abs(dx)>45)(dx<0?next:prev)()});
document.addEventListener("keydown",e=>{if(e.key==="ArrowRight")next();if(e.key==="ArrowLeft")prev()});

const audio=document.getElementById("oceanAudio"), sound=document.getElementById("soundBtn");
let soundOn=false;
function playSound(){audio.play().then(()=>{soundOn=true;sound.textContent="🔊"}).catch(()=>{})}
document.querySelector(".slide1 .btn").addEventListener("click",playSound);
sound.onclick=()=>{if(audio.paused)playSound();else{audio.pause();soundOn=false;sound.textContent="🔇"}};

const chest=document.getElementById("chest"), treasure=document.getElementById("treasureContent");
function openChest(){chest.parentElement.classList.add("hidden");treasure.classList.remove("hidden");confetti()}
chest.onclick=openChest;chest.onkeydown=e=>{if(e.key==="Enter"||e.key===" ")openChest()};

function confetti(){for(let i=0;i<70;i++){const x=document.createElement("span");x.textContent=["🎉","✨","⭐","💙","💛"][Math.floor(Math.random()*5)];x.style.position="fixed";x.style.left=(Math.random()*100)+"vw";x.style.top="-30px";x.style.fontSize=(12+Math.random()*18)+"px";x.style.zIndex=99;x.style.transition=`transform ${2+Math.random()*2}s linear, opacity 2.5s`;document.body.appendChild(x);requestAnimationFrame(()=>{x.style.transform=`translate(${(Math.random()-.5)*150}px, ${window.innerHeight+80}px) rotate(${Math.random()*720}deg)`;x.style.opacity=0});setTimeout(()=>x.remove(),4300)}}
document.getElementById("confettiBtn").onclick=confetti;

const answer=document.getElementById("answer"), unlock=document.getElementById("unlockBtn"), msg=document.getElementById("secretMessage"), error=document.getElementById("error");
function check(){const v=answer.value.replace(/\s/g,"");if(v==="150"||v==="153"){error.textContent="";msg.classList.remove("hidden");unlock.classList.add("hidden");answer.classList.add("hidden");confetti()}else error.textContent="Hmm… belum tepat, captain. Coba lagi 😉"}
unlock.onclick=check;answer.addEventListener("keydown",e=>{if(e.key==="Enter")check()});
document.getElementById("restartBtn").onclick=()=>go(0);
