# Rofil 21st Birthday — Grand Line
Mobile-first, swipeable One Piece/ocean-inspired birthday website.
## Run
Open `index.html` locally or deploy the folder to GitHub Pages.
## Optional ocean audio
Put an audio file named `ocean.mp3` inside `assets/` to enable the ambience button.
## Secret message
The accepted answers are 150 or 153. They are intentionally NOT displayed in the page UI; the answer is checked in JavaScript.
